#!/bin/bash

function check_code_LST() {
cat $_folder/work/CODE.LST
}

function compile_asm_code() {

export LABFILE=code.asm
export LABFILE_NAME="${LABFILE%.*}"
export LABFILE_BIG_NAME=${LABFILE_NAME^^}

cp "$_folder/work/$LABFILE" "$_folder/ASM51/$LABFILE"
(cd "$_folder/ASM51" && WINEPREFIX=$_folder/pfx WINEARCH="win32" wine ASM51.EXE $LABFILE)
cp $_folder/ASM51/$LABFILE_BIG_NAME.??? $_folder/work
# В папке work будут "TEST.HEX" и "TEST.LST" файлы.
echo ""
echo ""
echo ""
echo "Look $LABFILE_BIG_NAME.HEX and $LABFILE_BIG_NAME.LST in $_folder/work/"
export COMPILE_RES=$(cat $_folder/work/$LABFILE_BIG_NAME.LST | grep "0 ERRORS FOUND")
if [ -z "$COMPILE_RES" ]
then
      echo "!!!Error while compile!!!"
      echo "Content of $LABFILE_BIG_NAME.LST:"
      echo "\"\"\""
      echo $(cat $_folder/work/$LABFILE_BIG_NAME.LST)
      echo "\"\"\""
      echo "Compilled: ERROR"
else
      echo "Compilled: OK"
fi
}

function run_ADSIM812() {
(cd $_folder/ADSIM812 && WINEPREFIX=$_folder/pfx WINEARCH="win32" wine "ADSIM812.EXE")

}

function init_prefix() {
WINEPREFIX=$_folder/pfx WINEARCH="win32" winecfg
}

function manageMenu() {
	echo "What do you want to do?"
	echo "   1) Init prefix"
	echo "   2) Run ADSIM812.EXE"
	echo "   3) Compile ./work/code.asm"
	echo "   4) Check   ./work/CODE.LST"
	echo "   5) Exit"
	until [[ ${MENU_OPTION} =~ ^[1-5]$ ]]; do
		read -rp "Select an option [1-5]: " MENU_OPTION
	done
	case "${MENU_OPTION}" in
	1)
		init_prefix
		;;
	2)
		run_ADSIM812
		;;
	3)
		compile_asm_code
		;;
	4)
		check_code_LST
		;;
	5)
		exit 0
		;;
	esac
}



export _folder=$(dirname "$(realpath "$0")")

manageMenu
